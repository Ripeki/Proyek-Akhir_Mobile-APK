package com.example.e_commerceprojectakhir.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.e_commerceprojectakhir.R

class BaruActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_baru)
    }
}