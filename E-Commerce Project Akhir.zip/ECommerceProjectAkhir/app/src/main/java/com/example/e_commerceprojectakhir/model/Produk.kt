package com.example.e_commerceprojectakhir.model

import java.io.Serializable

class Produk : Serializable {
    var nama:String = ""
    var harga:String = ""
    var gambar:Int = 0
}